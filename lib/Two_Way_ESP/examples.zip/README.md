# TwoWayESP

A simple library that will allow easy communication between ESP devices.

The library is names Two Way but you can easily send one way only
